<?php
// scans.php
// All Scans List

require_once __DIR__ . '/includes/db.php';

$pageTitle = 'Scans';
$db = getDB();

$scans = $db->query("
    SELECT s.*, 
        (SELECT COUNT(*) FROM findings WHERE scan_id = s.id) as finding_count,
        (SELECT COUNT(*) FROM findings WHERE scan_id = s.id AND severity = 'critical') as critical_count
    FROM scans s 
    ORDER BY created_at DESC
")->fetchAll();

require_once __DIR__ . '/templates/header.php';
?>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">All Security Scans</div>
            <div class="card-subtitle"><?= count($scans) ?> total assessments</div>
        </div>
        <a href="/new_scan.php" class="btn btn-primary btn-sm">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 2v10M2 7h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
            New Scan
        </a>
    </div>

    <?php if (empty($scans)): ?>
        <div class="empty-state">
            <h3>No scans found</h3>
            <p>Start your first security assessment.</p>
            <a href="/new_scan.php" class="btn btn-primary">Create Scan</a>
        </div>
    <?php else: ?>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Target</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Findings</th>
                        <th>Progress</th>
                        <th>Created</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($scans as $scan): ?>
                    <tr>
                        <td style="font-family: var(--font-mono); font-size: 0.82rem; color: var(--text-dim);">#<?= $scan['id'] ?></td>
                        <td style="font-weight: 500; color: var(--text-primary);"><?= htmlspecialchars($scan['scan_name']) ?></td>
                        <td style="font-family: var(--font-mono); font-size: 0.82rem;"><?= htmlspecialchars($scan['target_url']) ?></td>
                        <td><?= ucfirst($scan['scan_type']) ?></td>
                        <td><span class="badge badge-<?= $scan['status'] ?>"><?= ucfirst($scan['status']) ?></span></td>
                        <td>
                            <?php if ($scan['critical_count'] > 0): ?>
                                <span class="badge badge-critical"><?= $scan['critical_count'] ?> critical</span>
                            <?php endif; ?>
                            <?= $scan['finding_count'] ?> total
                        </td>
                        <td>
                            <div class="scan-progress">
                                <div class="progress-bar">
                                    <div class="progress-fill <?= $scan['status'] === 'complete' ? 'complete' : '' ?>" style="width: <?= $scan['progress'] ?>%"></div>
                                </div>
                                <span class="progress-text"><?= $scan['progress'] ?>%</span>
                            </div>
                        </td>
                        <td style="font-size: 0.82rem; color: var(--text-muted);"><?= date('M j, Y', strtotime($scan['created_at'])) ?></td>
                        <td>
                            <div style="display: flex; gap: 6px;">
                                <a href="/scan_detail.php?id=<?= $scan['id'] ?>" class="btn btn-secondary btn-sm">View</a>
                                <button onclick="deleteScan(<?= $scan['id'] ?>)" class="btn btn-danger btn-sm">Del</button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
function deleteScan(id) {
    if (!confirm('Delete this scan and all its data? This cannot be undone.')) return;

    fetch('/api/delete_scan.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({scan_id: id})
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showToast('Scan deleted', 'success');
            setTimeout(() => location.reload(), 500);
        } else {
            showToast('Failed to delete scan', 'error');
        }
    });
}
</script>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
