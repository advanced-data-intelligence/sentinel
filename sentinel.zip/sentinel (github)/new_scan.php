<?php
// new_scan.php
// Create New Scan

require_once __DIR__ . '/includes/db.php';

$pageTitle = 'New Scan';
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $scanName = trim($_POST['scan_name'] ?? '');
    $targetUrl = trim($_POST['target_url'] ?? '');
    $sourcePath = trim($_POST['source_path'] ?? '');
    $scanType = $_POST['scan_type'] ?? 'full';

    // Validation
    if (empty($scanName)) {
        $error = 'Scan name is required.';
    } elseif (empty($targetUrl) || !filter_var($targetUrl, FILTER_VALIDATE_URL)) {
        $error = 'A valid target URL is required.';
    } elseif ($sourcePath && !is_dir($sourcePath)) {
        $error = 'Source code path does not exist or is not a directory.';
    } elseif (!in_array($scanType, ['full', 'recon', 'vuln_analysis', 'quick'])) {
        $error = 'Invalid scan type.';
    } else {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO scans (scan_name, target_url, source_path, scan_type, status) VALUES (?, ?, ?, ?, 'pending')");
        $stmt->execute([$scanName, $targetUrl, $sourcePath ?: null, $scanType]);
        $scanId = $db->lastInsertId();

        // Redirect to scan detail page
        header("Location: /scan_detail.php?id={$scanId}&autostart=1");
        exit;
    }
}

require_once __DIR__ . '/templates/header.php';
?>

<div style="max-width: 720px;">
    <?php if ($error): ?>
        <div class="toast toast-error" style="margin-bottom: 20px; position: static;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title">Configure Security Assessment</div>
                <div class="card-subtitle">Set up your target and scan parameters</div>
            </div>
        </div>

        <form method="POST" action="/new_scan.php">
            <div class="form-group">
                <label class="form-label">Scan Name</label>
                <input type="text" name="scan_name" class="form-input" placeholder="e.g., My App - Full Pentest" value="<?= htmlspecialchars($_POST['scan_name'] ?? '') ?>" required>
                <div class="form-hint">A descriptive name for this security assessment</div>
            </div>

            <div class="form-group">
                <label class="form-label">Target URL</label>
                <input type="url" name="target_url" class="form-input" placeholder="https://staging.yourapp.com" value="<?= htmlspecialchars($_POST['target_url'] ?? '') ?>" required>
                <div class="form-hint">The live URL of the application to test. Never use production!</div>
            </div>

            <div class="form-group">
                <label class="form-label">Source Code Path (optional)</label>
                <input type="text" name="source_path" class="form-input" placeholder="/home/user/projects/myapp" value="<?= htmlspecialchars($_POST['source_path'] ?? '') ?>">
                <div class="form-hint">Absolute path to the source code directory for white-box analysis</div>
            </div>

            <div class="form-group">
                <label class="form-label">Scan Type</label>
                <select name="scan_type" class="form-select">
                    <option value="full">Full Scan — Recon + Vuln Scan + AI Analysis + Code Review</option>
                    <option value="quick">Quick Scan — Recon + Vuln Scan (skip deep AI analysis)</option>
                    <option value="recon">Recon Only — Fingerprinting, port scan, directory enum</option>
                    <option value="vuln_analysis">Vuln Analysis Only — Nikto, Nuclei, SQLMap</option>
                </select>
                <div class="form-hint">Full scans use Ollama for AI-powered analysis and take longer</div>
            </div>

            <div style="display: flex; gap: 12px; margin-top: 28px;">
                <button type="submit" class="btn btn-primary btn-lg">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M9 3L4.5 5.25v4.5c0 3.94 1.92 7.6 4.5 8.55 2.58-.95 4.5-4.61 4.5-8.55v-4.5L9 3z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><path d="M6.75 9l1.5 1.5 3-3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    Launch Scan
                </button>
                <a href="/index.php" class="btn btn-secondary btn-lg">Cancel</a>
            </div>
        </form>
    </div>

    <!-- Warning Box -->
    <div class="card" style="margin-top: 20px; border-color: rgba(234, 179, 8, 0.2);">
        <div style="display: flex; gap: 12px; align-items: flex-start;">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" style="flex-shrink: 0; color: var(--severity-medium);"><path d="M10 3L2 17h16L10 3z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><path d="M10 8v4M10 14v.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
            <div style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.6;">
                <strong style="color: var(--severity-medium);">Important:</strong> Only scan applications you own or have written permission to test. Security tools actively probe for vulnerabilities and may modify data. Never target production environments.
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
