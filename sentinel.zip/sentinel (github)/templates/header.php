<?php
// templates/header.php
// Sentinel - Shared Header Template

require_once __DIR__ . '/../includes/db.php';

$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'Sentinel') ?> - Sentinel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="32" height="32" rx="8" fill="#0ea5e9"/>
                        <path d="M16 6L8 10v6c0 5.25 3.4 10.15 8 11.4 4.6-1.25 8-6.15 8-11.4v-6L16 6z" fill="#0c1425" stroke="#38bdf8" stroke-width="1.5"/>
                        <circle cx="16" cy="15" r="3" fill="#38bdf8"/>
                        <path d="M16 18v3" stroke="#38bdf8" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                    <span class="logo-text">Sentinel</span>
                </div>
                <span class="version-badge">v1.0</span>
            </div>

            <nav class="sidebar-nav">
                <a href="/index.php" class="nav-item <?= $currentPage === 'index' ? 'active' : '' ?>">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M2.25 9.75L9 3l6.75 6.75M3.75 8.25v6a.75.75 0 00.75.75h3v-3.75h3V15h3a.75.75 0 00.75-.75v-6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    <span>Dashboard</span>
                </a>
                <a href="/new_scan.php" class="nav-item <?= $currentPage === 'new_scan' ? 'active' : '' ?>">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M9 3v12M3 9h12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                    <span>New Scan</span>
                </a>
                <a href="/scans.php" class="nav-item <?= $currentPage === 'scans' ? 'active' : '' ?>">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M2.25 4.5h13.5M2.25 9h13.5M2.25 13.5h9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                    <span>Scans</span>
                </a>
                <a href="/reports.php" class="nav-item <?= $currentPage === 'reports' ? 'active' : '' ?>">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M10.5 2.25H4.5a1.5 1.5 0 00-1.5 1.5v10.5a1.5 1.5 0 001.5 1.5h9a1.5 1.5 0 001.5-1.5V6.75L10.5 2.25z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.5 2.25v4.5H15M6 9.75h6M6 12.75h6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    <span>Reports</span>
                </a>
                <a href="/settings.php" class="nav-item <?= $currentPage === 'settings' ? 'active' : '' ?>">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M7.5 2.25h3L12 4.5l2.25.75.75 2.25L13.5 9l1.5 1.5-.75 2.25-2.25.75L10.5 15.75h-3L6 13.5l-2.25-.75L3 10.5 4.5 9 3 7.5l.75-2.25L6 4.5 7.5 2.25z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><circle cx="9" cy="9" r="2.25" stroke="currentColor" stroke-width="1.5"/></svg>
                    <span>Settings</span>
                </a>
            </nav>

            <div class="sidebar-footer">
                <div class="ollama-status" id="ollamaStatus">
                    <span class="status-dot"></span>
                    <span class="status-text">Checking...</span>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="topbar">
                <h1 class="page-title"><?= htmlspecialchars($pageTitle ?? 'Dashboard') ?></h1>
                <div class="topbar-actions">
                    <span class="clock" id="clock"></span>
                </div>
            </header>
            <div class="content-area">
