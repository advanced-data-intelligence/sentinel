<?php
// templates/footer.php
// Sentinel - Shared Footer Template
?>
            </div>
        </main>
    </div>

    <script src="/assets/js/app.js"></script>
    <?php if (isset($extraScripts)): ?>
        <?php foreach ($extraScripts as $script): ?>
            <script src="<?= htmlspecialchars($script) ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>
