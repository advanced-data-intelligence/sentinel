<?php
// api/scan_logs.php
// Scan Logs Polling API

header('Content-Type: application/json');
require_once __DIR__ . '/../includes/db.php';

$scanId = intval($_GET['scan_id'] ?? 0);
$afterId = intval($_GET['after_id'] ?? 0);

if (!$scanId) {
    echo json_encode(['logs' => []]);
    exit;
}

$db = getDB();

$stmt = $db->prepare("SELECT id, log_level, message, created_at FROM scan_logs WHERE scan_id = ? AND id > ? ORDER BY id ASC LIMIT 50");
$stmt->execute([$scanId, $afterId]);
$logs = $stmt->fetchAll();

$stmt = $db->prepare("SELECT status FROM scans WHERE id = ?");
$stmt->execute([$scanId]);
$scan = $stmt->fetch();

$formatted = array_map(function($log) {
    return [
        'id' => $log['id'],
        'level' => $log['log_level'],
        'message' => $log['message'],
        'time' => date('H:i:s', strtotime($log['created_at'])),
    ];
}, $logs);

echo json_encode([
    'logs' => $formatted,
    'scan_status' => $scan['status'] ?? 'unknown',
]);
