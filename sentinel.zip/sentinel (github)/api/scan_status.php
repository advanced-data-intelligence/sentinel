<?php
// api/scan_status.php
// Scan Status Polling API

header('Content-Type: application/json');
require_once __DIR__ . '/../includes/db.php';

$scanId = intval($_GET['id'] ?? 0);

if (!$scanId) {
    echo json_encode(['error' => 'Missing scan id']);
    exit;
}

$db = getDB();
$stmt = $db->prepare("SELECT id, status, progress, current_phase, started_at, completed_at FROM scans WHERE id = ?");
$stmt->execute([$scanId]);
$scan = $stmt->fetch();

if (!$scan) {
    echo json_encode(['error' => 'Scan not found']);
    exit;
}

echo json_encode($scan);
