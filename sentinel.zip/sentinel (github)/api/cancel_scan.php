<?php
// api/cancel_scan.php
// Cancel a Running Scan

header('Content-Type: application/json');
require_once __DIR__ . '/../includes/db.php';

$input = json_decode(file_get_contents('php://input'), true);
$scanId = intval($input['scan_id'] ?? 0);

if (!$scanId) {
    echo json_encode(['success' => false, 'error' => 'Missing scan_id']);
    exit;
}

$db = getDB();
$stmt = $db->prepare("UPDATE scans SET status = 'cancelled', completed_at = NOW() WHERE id = ? AND status IN ('running', 'analyzing', 'pending')");
$stmt->execute([$scanId]);

addScanLog($scanId, "Scan cancelled by user", 'warning');

echo json_encode(['success' => true]);
