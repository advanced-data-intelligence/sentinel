<?php
// api/delete_scan.php
// Delete Scan and All Associated Data

header('Content-Type: application/json');
require_once __DIR__ . '/../includes/db.php';

$input = json_decode(file_get_contents('php://input'), true);
$scanId = intval($input['scan_id'] ?? 0);

if (!$scanId) {
    echo json_encode(['success' => false, 'error' => 'Missing scan_id']);
    exit;
}

$db = getDB();

// Delete report files
$stmt = $db->prepare("SELECT file_path FROM reports WHERE scan_id = ?");
$stmt->execute([$scanId]);
while ($row = $stmt->fetch()) {
    if ($row['file_path'] && file_exists($row['file_path'])) {
        unlink($row['file_path']);
    }
}

// Cascade delete handles findings, scan_results, scan_logs, reports
$stmt = $db->prepare("DELETE FROM scans WHERE id = ?");
$stmt->execute([$scanId]);

echo json_encode(['success' => true]);
