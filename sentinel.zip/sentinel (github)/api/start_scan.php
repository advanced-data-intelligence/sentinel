<?php
// api/start_scan.php
// Start Scan API - Launches scan as a background process

header('Content-Type: application/json');
require_once __DIR__ . '/../includes/db.php';

$input = json_decode(file_get_contents('php://input'), true);
$scanId = intval($input['scan_id'] ?? 0);

if (!$scanId) {
    echo json_encode(['success' => false, 'error' => 'Missing scan_id']);
    exit;
}

$db = getDB();
$stmt = $db->prepare("SELECT * FROM scans WHERE id = ? AND status = 'pending'");
$stmt->execute([$scanId]);
$scan = $stmt->fetch();

if (!$scan) {
    echo json_encode(['success' => false, 'error' => 'Scan not found or already started']);
    exit;
}

// Update status to running
$stmt = $db->prepare("UPDATE scans SET status = 'running', started_at = NOW() WHERE id = ?");
$stmt->execute([$scanId]);

// Launch the scanner as a background process
$runnerScript = realpath(__DIR__ . '/../run_scan.php');
$logFile = '/tmp/sentinel_scan_' . $scanId . '.log';
$cmd = sprintf(
    'nohup php %s %d > %s 2>&1 < /dev/null &',
    escapeshellarg($runnerScript),
    $scanId,
    escapeshellarg($logFile)
);

exec($cmd . ' echo $!', $output);

addScanLog($scanId, "Scan launched via API (PID background process)", 'info');

echo json_encode([
    'success' => true,
    'scan_id' => $scanId,
    'message' => 'Scan started',
]);
