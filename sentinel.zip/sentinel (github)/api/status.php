<?php
// api/status.php
// System & Ollama Status Check API

header('Content-Type: application/json');
require_once __DIR__ . '/../includes/ollama.php';

$ollama = new OllamaClient();
$health = $ollama->healthCheck();

echo json_encode([
    'ollama_online' => $health['online'],
    'model_available' => $health['model_available'],
    'configured_model' => $health['configured_model'],
    'available_models' => $health['available_models'] ?? [],
]);
