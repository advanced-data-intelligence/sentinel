<?php
// config.example.php
// Sentinel - Database & Application Configuration
// Copy this file to config.php and fill in your own values.
// config.php is gitignored so your real credentials never get committed.

define('APP_NAME', 'Sentinel');
define('APP_VERSION', '1.0.0');
define('APP_ROOT', __DIR__);

// Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'sentinel_db');
define('DB_USER', 'sentinel_user');
define('DB_PASS', 'CHANGE_ME_TO_YOUR_DB_PASSWORD');
define('DB_CHARSET', 'utf8mb4');

// Paths
define('REPORTS_DIR', APP_ROOT . '/reports');
define('TOOLS_DIR', APP_ROOT . '/tools');
define('UPLOADS_DIR', APP_ROOT . '/uploads');

// Ollama defaults (overridden by DB settings table once seeded)
define('OLLAMA_URL_DEFAULT', 'http://localhost:11434');
define('OLLAMA_MODEL_DEFAULT', 'nemotron-3-nano:30b-cloud');