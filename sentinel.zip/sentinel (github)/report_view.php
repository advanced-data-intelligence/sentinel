<?php
// report_view.php
// Report Viewer - Renders markdown report

require_once __DIR__ . '/includes/db.php';

$reportId = intval($_GET['id'] ?? 0);
$db = getDB();

$stmt = $db->prepare("SELECT r.*, s.scan_name, s.target_url FROM reports r JOIN scans s ON r.scan_id = s.id WHERE r.id = ?");
$stmt->execute([$reportId]);
$report = $stmt->fetch();

if (!$report) {
    header("Location: /reports.php");
    exit;
}

$pageTitle = 'Report: ' . htmlspecialchars($report['scan_name']);
require_once __DIR__ . '/templates/header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <div>
        <div style="font-size: 0.82rem; color: var(--text-muted);">
            Target: <span style="font-family: var(--font-mono); color: var(--accent);"><?= htmlspecialchars($report['target_url']) ?></span>
            &middot; Generated: <?= date('M j, Y g:ia', strtotime($report['generated_at'])) ?>
        </div>
    </div>
    <div style="display: flex; gap: 8px;">
        <button onclick="downloadReport()" class="btn btn-primary btn-sm">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 2v8M4 7l3 3 3-3M2.5 11.5h9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            Download .md
        </button>
        <a href="/reports.php" class="btn btn-secondary btn-sm">Back</a>
    </div>
</div>

<div class="card" style="max-width: 900px;">
    <div id="reportContent" style="font-size: 0.9rem; line-height: 1.8; color: var(--text-secondary);">
        <?= nl2br(htmlspecialchars($report['content'])) ?>
    </div>
</div>

<script>
function downloadReport() {
    const content = <?= json_encode($report['content']) ?>;
    const blob = new Blob([content], {type: 'text/markdown'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sentinel_report_<?= $report['scan_id'] ?>.md';
    a.click();
    URL.revokeObjectURL(url);
}
</script>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
