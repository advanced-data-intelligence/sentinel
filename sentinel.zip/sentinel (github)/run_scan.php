<?php
// run_scan.php
// Background Scan Runner - Executed via CLI by the API
// Usage: php run_scan.php <scan_id>

// Ensure running from CLI
if (php_sapi_name() !== 'cli') {
    die("This script must be run from the command line.\n");
}

$scanId = intval($argv[1] ?? 0);
if (!$scanId) {
    die("Usage: php run_scan.php <scan_id>\n");
}

require_once __DIR__ . '/includes/scanner.php';

// Set generous limits for long-running scans
set_time_limit(0);
ini_set('memory_limit', '512M');

echo "[Sentinel] Starting scan #{$scanId}\n";

try {
    $scanner = new Scanner($scanId);
    $scanner->run();
    echo "[Sentinel] Scan #{$scanId} completed successfully.\n";
} catch (\Exception $e) {
    echo "[Sentinel] Scan #{$scanId} failed: " . $e->getMessage() . "\n";

    // Update status to failed
    require_once __DIR__ . '/includes/db.php';
    $db = getDB();
    $stmt = $db->prepare("UPDATE scans SET status = 'failed', completed_at = NOW(), current_phase = ? WHERE id = ?");
    $stmt->execute(['Failed: ' . $e->getMessage(), $scanId]);
    addScanLog($scanId, 'Fatal error: ' . $e->getMessage(), 'error');
}
