<?php
// scan_detail.php
// Scan Detail View with Live Progress

require_once __DIR__ . '/includes/db.php';

$scanId = intval($_GET['id'] ?? 0);
$autostart = intval($_GET['autostart'] ?? 0);

$db = getDB();
$stmt = $db->prepare("SELECT * FROM scans WHERE id = ?");
$stmt->execute([$scanId]);
$scan = $stmt->fetch();

if (!$scan) {
    header("Location: /scans.php");
    exit;
}

// Get findings
$stmt = $db->prepare("SELECT * FROM findings WHERE scan_id = ? ORDER BY FIELD(severity, 'critical', 'high', 'medium', 'low', 'info')");
$stmt->execute([$scanId]);
$findings = $stmt->fetchAll();

// Get tool results
$stmt = $db->prepare("SELECT * FROM scan_results WHERE scan_id = ? ORDER BY started_at");
$stmt->execute([$scanId]);
$toolResults = $stmt->fetchAll();

// Get report
$stmt = $db->prepare("SELECT * FROM reports WHERE scan_id = ? LIMIT 1");
$stmt->execute([$scanId]);
$report = $stmt->fetch();

// Get logs
$stmt = $db->prepare("SELECT * FROM scan_logs WHERE scan_id = ? ORDER BY created_at DESC LIMIT 100");
$stmt->execute([$scanId]);
$logs = array_reverse($stmt->fetchAll());

$pageTitle = htmlspecialchars($scan['scan_name']);
require_once __DIR__ . '/templates/header.php';
?>

<!-- Scan Info Header -->
<div class="card section">
    <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 16px;">
        <div>
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                <span class="badge badge-<?= $scan['status'] ?>"><?= ucfirst($scan['status']) ?></span>
                <span style="font-size: 0.82rem; color: var(--text-muted);"><?= ucfirst($scan['scan_type']) ?> Scan</span>
            </div>
            <div style="font-family: var(--font-mono); font-size: 0.88rem; color: var(--accent); margin-bottom: 4px;">
                <?= htmlspecialchars($scan['target_url']) ?>
            </div>
            <?php if ($scan['source_path']): ?>
                <div style="font-size: 0.8rem; color: var(--text-muted);">Source: <?= htmlspecialchars($scan['source_path']) ?></div>
            <?php endif; ?>
        </div>
        <div style="display: flex; gap: 8px;">
            <?php if (in_array($scan['status'], ['pending'])): ?>
                <button onclick="startScan(<?= $scanId ?>)" class="btn btn-primary btn-sm" id="btnStart">
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><polygon points="3,1 12,7 3,13" fill="currentColor"/></svg>
                    Start
                </button>
            <?php endif; ?>
            <?php if (in_array($scan['status'], ['running', 'analyzing'])): ?>
                <button onclick="cancelScan(<?= $scanId ?>)" class="btn btn-danger btn-sm">Cancel</button>
            <?php endif; ?>
            <?php if ($report): ?>
                <a href="/report_view.php?id=<?= $report['id'] ?>" class="btn btn-secondary btn-sm">View Report</a>
            <?php endif; ?>
            <a href="/scans.php" class="btn btn-secondary btn-sm">Back</a>
        </div>
    </div>

    <!-- Progress Bar -->
    <div class="scan-progress" style="margin-top: 20px;" id="progressSection">
        <div class="progress-bar" style="height: 8px;">
            <div class="progress-fill <?= $scan['status'] === 'complete' ? 'complete' : '' ?>" id="progressBar" style="width: <?= $scan['progress'] ?>%"></div>
        </div>
        <span class="progress-text" id="progressText"><?= $scan['progress'] ?>%</span>
    </div>
    <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 6px;" id="phaseText">
        <?= htmlspecialchars($scan['current_phase'] ?? '') ?>
    </div>
</div>

<!-- Findings Summary -->
<?php if (!empty($findings)): ?>
<div class="section">
    <div class="section-title">Findings (<?= count($findings) ?>)</div>

    <?php
    $bySeverity = [];
    foreach ($findings as $f) {
        $bySeverity[$f['severity']][] = $f;
    }
    ?>

    <?php foreach (['critical', 'high', 'medium', 'low', 'info'] as $sev): ?>
        <?php if (!empty($bySeverity[$sev])): ?>
            <?php foreach ($bySeverity[$sev] as $f): ?>
                <div class="finding-item">
                    <div class="finding-header">
                        <span class="badge badge-<?= $sev ?>"><?= ucfirst($sev) ?></span>
                        <span class="finding-title"><?= htmlspecialchars($f['title']) ?></span>
                    </div>
                    <div class="finding-meta">
                        <span><?= htmlspecialchars($f['category']) ?></span>
                        <span>Source: <?= htmlspecialchars($f['source_tool']) ?></span>
                        <?php if ($f['ai_confidence']): ?>
                            <span>Confidence: <?= round($f['ai_confidence'] * 100) ?>%</span>
                        <?php endif; ?>
                    </div>
                    <?php if ($f['description']): ?>
                        <div class="finding-description"><?= nl2br(htmlspecialchars($f['description'])) ?></div>
                    <?php endif; ?>
                    <?php if ($f['proof_of_concept']): ?>
                        <div class="code-block"><?= htmlspecialchars($f['proof_of_concept']) ?></div>
                    <?php endif; ?>
                    <?php if ($f['remediation']): ?>
                        <div style="margin-top: 8px; font-size: 0.82rem;">
                            <strong style="color: var(--severity-low);">Remediation:</strong>
                            <span style="color: var(--text-secondary);"><?= htmlspecialchars($f['remediation']) ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Tool Results -->
<?php if (!empty($toolResults)): ?>
<div class="card section">
    <div class="card-header">
        <div class="card-title">Tool Results</div>
    </div>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Tool</th>
                    <th>Phase</th>
                    <th>Status</th>
                    <th>Started</th>
                    <th>Duration</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($toolResults as $tr): ?>
                <tr>
                    <td style="font-weight: 500; color: var(--text-primary);"><?= htmlspecialchars($tr['tool_name']) ?></td>
                    <td><?= ucfirst($tr['phase']) ?></td>
                    <td><span class="badge badge-<?= $tr['status'] ?>"><?= ucfirst($tr['status']) ?></span></td>
                    <td style="font-size: 0.82rem; color: var(--text-muted);">
                        <?= $tr['started_at'] ? date('g:i:s a', strtotime($tr['started_at'])) : '-' ?>
                    </td>
                    <td style="font-family: var(--font-mono); font-size: 0.82rem;">
                        <?php
                        if ($tr['started_at'] && $tr['completed_at']) {
                            $diff = strtotime($tr['completed_at']) - strtotime($tr['started_at']);
                            echo $diff < 60 ? "{$diff}s" : round($diff / 60, 1) . 'm';
                        } else {
                            echo '-';
                        }
                        ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Live Logs -->
<div class="card">
    <div class="card-header">
        <div class="card-title">Scan Logs</div>
        <span style="font-family: var(--font-mono); font-size: 0.75rem; color: var(--text-dim);" id="logCount"><?= count($logs) ?> entries</span>
    </div>
    <div class="log-viewer" id="logViewer">
        <?php foreach ($logs as $log): ?>
            <div class="log-entry">
                <span class="log-time"><?= date('H:i:s', strtotime($log['created_at'])) ?></span>
                <span class="log-level <?= $log['log_level'] ?>"><?= $log['log_level'] ?></span>
                <span class="log-message"><?= htmlspecialchars($log['message']) ?></span>
            </div>
        <?php endforeach; ?>
        <?php if (empty($logs)): ?>
            <div class="log-entry">
                <span class="log-message" style="color: var(--text-dim);">No log entries yet. Start the scan to see output.</span>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
const scanId = <?= $scanId ?>;
const autostart = <?= $autostart ?>;

if (autostart && '<?= $scan['status'] ?>' === 'pending') {
    startScan(scanId);
}

// If scan is running, start polling
if (['running', 'analyzing'].includes('<?= $scan['status'] ?>')) {
    startPolling();
}

function startScan(id) {
    const btn = document.getElementById('btnStart');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = 'Starting...';
    }

    fetch('/api/start_scan.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({scan_id: id})
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showToast('Scan started', 'success');
            startPolling();
            if (btn) btn.remove();
        } else {
            showToast('Failed to start scan: ' + (data.error || ''), 'error');
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = 'Start';
            }
        }
    })
    .catch(err => {
        showToast('Error: ' + err.message, 'error');
    });
}

function cancelScan(id) {
    if (!confirm('Cancel this scan?')) return;
    fetch('/api/cancel_scan.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({scan_id: id})
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    });
}

function startPolling() {
    pollScanStatus(scanId, function(data) {
        document.getElementById('progressBar').style.width = data.progress + '%';
        document.getElementById('progressText').textContent = data.progress + '%';
        document.getElementById('phaseText').textContent = data.current_phase || '';

        if (data.status === 'complete') {
            document.getElementById('progressBar').classList.add('complete');
            showToast('Scan complete!', 'success');
            setTimeout(() => location.reload(), 1500);
        } else if (data.status === 'failed') {
            document.getElementById('progressBar').classList.add('critical');
            showToast('Scan failed', 'error');
            setTimeout(() => location.reload(), 1500);
        }
    });

    // Poll logs
    let lastLogId = <?= !empty($logs) ? end($logs)['id'] : 0 ?>;
    const logViewer = document.getElementById('logViewer');
    pollScanLogs(scanId, logViewer, lastLogId);
}
</script>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
