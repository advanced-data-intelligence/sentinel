# Sentinel - Local AI Pentesting Co-Pilot
# Installation Guide for Ubuntu

> **Disclaimer** — Sentinel is intended for authorized security testing only.
> Use against systems you own or have explicit written permission to test.
> The authors accept no liability for misuse.

## Step 1: Install Security Tools

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Nmap (port scanning, service detection)
sudo apt install -y nmap

# Install Nikto (web server scanner)
sudo apt install -y nikto

# Install SQLMap (SQL injection tool)
sudo apt install -y sqlmap

# Install WhatWeb (web technology fingerprinting)
sudo apt install -y whatweb

# Install Dirb (directory brute-forcing)
sudo apt install -y dirb

# Install curl & jq (HTTP requests & JSON parsing)
sudo apt install -y curl jq unzip

# Install Subfinder (subdomain enumeration) - pull latest dynamically
SUBFINDER_URL=$(curl -s https://api.github.com/repos/projectdiscovery/subfinder/releases/latest | grep "browser_download_url.*linux_amd64.zip" | cut -d '"' -f 4)
wget "$SUBFINDER_URL"
unzip -o subfinder_*_linux_amd64.zip
sudo mv subfinder /usr/local/bin/
sudo chmod +x /usr/local/bin/subfinder
rm subfinder_*_linux_amd64.zip

# Install Nuclei (vulnerability scanner with templates) - pull latest dynamically
NUCLEI_URL=$(curl -s https://api.github.com/repos/projectdiscovery/nuclei/releases/latest | grep "browser_download_url.*linux_amd64.zip" | cut -d '"' -f 4)
wget "$NUCLEI_URL"
unzip -o nuclei_*_linux_amd64.zip
sudo mv nuclei /usr/local/bin/
sudo chmod +x /usr/local/bin/nuclei
rm nuclei_*_linux_amd64.zip

# Update Nuclei templates
nuclei -update-templates

# Verify all tools are installed
echo "=== Verifying Installations ==="
nmap --version | head -1
nikto -Version
sqlmap --version
whatweb --version | head -1
dirb 2>&1 | head -3
subfinder -version
nuclei -version
echo "=== All tools verified ==="
```

## Step 2: MariaDB Setup

```sql
CREATE DATABASE sentinel_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'sentinel_user'@'localhost' IDENTIFIED BY 'your_secure_password_here';
GRANT ALL PRIVILEGES ON sentinel_db.* TO 'sentinel_user'@'localhost';
FLUSH PRIVILEGES;
```

Then switch to the database and create the tables:

```sql
USE sentinel_db;

CREATE TABLE scans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scan_name VARCHAR(255) NOT NULL,
    target_url VARCHAR(500) NOT NULL,
    source_path VARCHAR(500) DEFAULT NULL,
    scan_type ENUM('full', 'recon', 'vuln_analysis', 'quick') DEFAULT 'full',
    status ENUM('pending', 'running', 'analyzing', 'complete', 'failed', 'cancelled') DEFAULT 'pending',
    progress INT DEFAULT 0,
    current_phase VARCHAR(100) DEFAULT NULL,
    started_at DATETIME DEFAULT NULL,
    completed_at DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE scan_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scan_id INT NOT NULL,
    tool_name VARCHAR(50) NOT NULL,
    phase VARCHAR(50) NOT NULL,
    raw_output LONGTEXT,
    parsed_data JSON DEFAULT NULL,
    status ENUM('pending', 'running', 'complete', 'failed') DEFAULT 'pending',
    started_at DATETIME DEFAULT NULL,
    completed_at DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
);

CREATE TABLE findings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scan_id INT NOT NULL,
    severity ENUM('critical', 'high', 'medium', 'low', 'info') DEFAULT 'info',
    category VARCHAR(100) NOT NULL,
    title VARCHAR(500) NOT NULL,
    description LONGTEXT,
    affected_url VARCHAR(500) DEFAULT NULL,
    affected_code TEXT DEFAULT NULL,
    proof_of_concept TEXT DEFAULT NULL,
    remediation TEXT DEFAULT NULL,
    ai_confidence DECIMAL(5,2) DEFAULT NULL,
    source_tool VARCHAR(50) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
);

CREATE TABLE reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scan_id INT NOT NULL,
    report_type ENUM('full', 'executive', 'technical') DEFAULT 'full',
    content LONGTEXT,
    file_path VARCHAR(500) DEFAULT NULL,
    generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
);

CREATE TABLE scan_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    scan_id INT NOT NULL,
    log_level ENUM('info', 'warning', 'error', 'debug') DEFAULT 'info',
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
);

CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO settings (setting_key, setting_value) VALUES
('ollama_url', 'http://localhost:11434'),
('ollama_model', 'nemotron-3-nano:30b-cloud'),
('max_concurrent_tools', '3'),
('scan_timeout_minutes', '120'),
('nmap_path', '/usr/bin/nmap'),
('nikto_path', '/usr/bin/nikto'),
('sqlmap_path', '/usr/bin/sqlmap'),
('whatweb_path', '/usr/bin/whatweb'),
('dirb_path', '/usr/bin/dirb'),
('subfinder_path', '/usr/local/bin/subfinder'),
('nuclei_path', '/usr/local/bin/nuclei');
```

## Step 3: Install Ollama + Nemotron Model

```bash
# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh
sudo systemctl enable --now ollama

# Sign in to Ollama cloud (required for cloud-hosted models)
ollama signin

# Pull the Nemotron-3-Nano 30B cloud model (1M context window)
ollama pull nemotron-3-nano:30b-cloud

# Verify the model is available
curl http://localhost:11434/api/tags | jq '.models[].name'
```

You should see `nemotron-3-nano:30b-cloud` in the output.

## Step 4: Configure Sentinel

```bash
# Copy the example config and fill in your DB password
cp /var/www/sentinel/config.example.php /var/www/sentinel/config.php
sudo nano /var/www/sentinel/config.php
```

Set `DB_PASS` to the password you used in Step 2.

## Step 5: Apache Virtual Host

```bash
sudo nano /etc/apache2/sites-available/sentinel.conf
```

```apache
<VirtualHost *:80>
    ServerName sentinel.example.com
    DocumentRoot /var/www/sentinel

    <Directory /var/www/sentinel>
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/sentinel_error.log
    CustomLog ${APACHE_LOG_DIR}/sentinel_access.log combined
</VirtualHost>
```

Replace `sentinel.example.com` with your own hostname (e.g. a Cloudflare Tunnel hostname, or `sentinel.local` for local-only use).

```bash
# Deploy the app
sudo cp -r /path/to/sentinel/* /var/www/sentinel/
sudo chown -R www-data:www-data /var/www/sentinel/
sudo chmod -R 755 /var/www/sentinel/

# The tools and reports directories need write permissions
sudo chmod -R 770 /var/www/sentinel/tools/
sudo chmod -R 770 /var/www/sentinel/reports/
sudo chmod -R 770 /var/www/sentinel/uploads/

# Enable the site and required modules
sudo a2ensite sentinel.conf
sudo a2enmod rewrite headers
sudo systemctl restart apache2

# If running locally, add to hosts file
echo "127.0.0.1 sentinel.local" | sudo tee -a /etc/hosts

# IMPORTANT: www-data needs permission to run security tools
echo 'www-data ALL=(ALL) NOPASSWD: /usr/bin/nmap, /usr/bin/nikto, /usr/bin/sqlmap, /usr/bin/whatweb, /usr/bin/dirb, /usr/local/bin/subfinder, /usr/local/bin/nuclei' | sudo tee /etc/sudoers.d/sentinel
sudo chmod 440 /etc/sudoers.d/sentinel
```

## Step 6: (Optional) SSL via Cloudflare Tunnel

Skip Let's Encrypt — Cloudflare Tunnel handles SSL at the edge.

```bash
cloudflared tunnel login
cloudflared tunnel create sentinel
cloudflared tunnel route dns sentinel sentinel.yourdomain.com
sudo cloudflared service install
```

## Step 7: First Launch

Open your Sentinel hostname in the browser. You should see the dashboard with a green **Ollama: nemotron-3-nano:30b-cloud** status dot in the sidebar, and all seven tool paths showing green checkmarks under **Settings**.

Hit **New Scan**, target a host you own or have permission to test, and launch your first pentest.
