<?php
// settings.php
// Application Settings

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/ollama.php';

$pageTitle = 'Settings';
$db = getDB();
$saved = false;

// Handle save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = [
        'ollama_url', 'ollama_model', 'max_concurrent_tools', 'scan_timeout_minutes',
        'nmap_path', 'nikto_path', 'sqlmap_path', 'whatweb_path', 'dirb_path',
        'subfinder_path', 'nuclei_path'
    ];

    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            setSetting($field, trim($_POST[$field]));
        }
    }
    $saved = true;
}

// Load current settings
$settings = [];
$rows = $db->query("SELECT setting_key, setting_value FROM settings")->fetchAll();
foreach ($rows as $row) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

// Ollama health check
$ollama = new OllamaClient();
$health = $ollama->healthCheck();

require_once __DIR__ . '/templates/header.php';
?>

<?php if ($saved): ?>
    <div class="toast toast-success" style="margin-bottom: 20px; position: static;">Settings saved successfully.</div>
<?php endif; ?>

<form method="POST" action="/settings.php">
    <div class="grid-2">
        <!-- Ollama Configuration -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Ollama Configuration</div>
            </div>

            <!-- Status indicator -->
            <div style="padding: 14px; border-radius: var(--radius); margin-bottom: 20px; border: 1px solid <?= $health['online'] ? 'rgba(34,197,94,0.2)' : 'rgba(239,68,68,0.2)' ?>; background: <?= $health['online'] ? 'rgba(34,197,94,0.06)' : 'rgba(239,68,68,0.06)' ?>;">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;">
                    <span class="status-dot <?= $health['online'] ? 'online' : 'offline' ?>"></span>
                    <strong style="font-size: 0.85rem; color: <?= $health['online'] ? 'var(--severity-low)' : 'var(--severity-critical)' ?>;">
                        <?= $health['online'] ? 'Ollama Online' : 'Ollama Offline' ?>
                    </strong>
                </div>
                <?php if ($health['online']): ?>
                    <div style="font-size: 0.8rem; color: var(--text-muted);">
                        Model "<?= htmlspecialchars($health['configured_model']) ?>":
                        <?= $health['model_available'] ? '<span style="color:var(--severity-low)">Available</span>' : '<span style="color:var(--severity-critical)">Not Found</span>' ?>
                    </div>
                    <?php if (!empty($health['available_models'])): ?>
                        <div style="font-size: 0.75rem; color: var(--text-dim); margin-top: 4px;">
                            Available: <?= htmlspecialchars(implode(', ', $health['available_models'])) ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div style="font-size: 0.8rem; color: var(--text-muted);">
                        <?= htmlspecialchars($health['error'] ?? 'Cannot connect to Ollama') ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label class="form-label">Ollama URL</label>
                <input type="text" name="ollama_url" class="form-input" value="<?= htmlspecialchars($settings['ollama_url'] ?? 'http://localhost:11434') ?>">
            </div>

            <div class="form-group">
                <label class="form-label">Model</label>
                <input type="text" name="ollama_model" class="form-input" value="<?= htmlspecialchars($settings['ollama_model'] ?? 'nemotron-3-nano:30b') ?>">
                <div class="form-hint">The Ollama model to use for AI analysis</div>
            </div>

            <div class="form-group">
                <label class="form-label">Max Concurrent Tools</label>
                <input type="number" name="max_concurrent_tools" class="form-input" value="<?= htmlspecialchars($settings['max_concurrent_tools'] ?? '3') ?>" min="1" max="10">
            </div>

            <div class="form-group">
                <label class="form-label">Scan Timeout (minutes)</label>
                <input type="number" name="scan_timeout_minutes" class="form-input" value="<?= htmlspecialchars($settings['scan_timeout_minutes'] ?? '120') ?>" min="10" max="480">
            </div>
        </div>

        <!-- Tool Paths -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Security Tool Paths</div>
            </div>

            <?php
            $toolFields = [
                'nmap_path' => ['Nmap', '/usr/bin/nmap'],
                'nikto_path' => ['Nikto', '/usr/bin/nikto'],
                'sqlmap_path' => ['SQLMap', '/usr/bin/sqlmap'],
                'whatweb_path' => ['WhatWeb', '/usr/bin/whatweb'],
                'dirb_path' => ['Dirb', '/usr/bin/dirb'],
                'subfinder_path' => ['Subfinder', '/usr/local/bin/subfinder'],
                'nuclei_path' => ['Nuclei', '/usr/local/bin/nuclei'],
            ];

            foreach ($toolFields as $key => [$label, $default]):
                $path = $settings[$key] ?? $default;
                $exists = file_exists($path);
            ?>
                <div class="form-group">
                    <label class="form-label">
                        <?= $label ?>
                        <?php if ($exists): ?>
                            <span style="color: var(--severity-low); font-size: 0.7rem;">&#10003; found</span>
                        <?php else: ?>
                            <span style="color: var(--severity-critical); font-size: 0.7rem;">&#10007; not found</span>
                        <?php endif; ?>
                    </label>
                    <input type="text" name="<?= $key ?>" class="form-input" value="<?= htmlspecialchars($path) ?>" style="font-family: var(--font-mono); font-size: 0.82rem;">
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div style="margin-top: 20px;">
        <button type="submit" class="btn btn-primary">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M13 5L6.5 11.5 3 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            Save Settings
        </button>
    </div>
</form>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
