<?php
// reports.php
// Generated Reports List

require_once __DIR__ . '/includes/db.php';

$pageTitle = 'Reports';
$db = getDB();

$reports = $db->query("
    SELECT r.*, s.scan_name, s.target_url,
        (SELECT COUNT(*) FROM findings WHERE scan_id = s.id) as finding_count,
        (SELECT COUNT(*) FROM findings WHERE scan_id = s.id AND severity = 'critical') as critical_count
    FROM reports r
    JOIN scans s ON r.scan_id = s.id
    ORDER BY r.generated_at DESC
")->fetchAll();

require_once __DIR__ . '/templates/header.php';
?>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">Security Reports</div>
            <div class="card-subtitle"><?= count($reports) ?> reports generated</div>
        </div>
    </div>

    <?php if (empty($reports)): ?>
        <div class="empty-state">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none"><path d="M26 6H12a3 3 0 00-3 3v27a3 3 0 003 3h24a3 3 0 003-3V19L26 6z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            <h3>No reports yet</h3>
            <p>Reports are generated automatically when scans complete.</p>
            <a href="/new_scan.php" class="btn btn-primary">Start a Scan</a>
        </div>
    <?php else: ?>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Scan</th>
                        <th>Target</th>
                        <th>Findings</th>
                        <th>Type</th>
                        <th>Generated</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reports as $r): ?>
                    <tr>
                        <td style="font-weight: 500; color: var(--text-primary);"><?= htmlspecialchars($r['scan_name']) ?></td>
                        <td style="font-family: var(--font-mono); font-size: 0.82rem;"><?= htmlspecialchars($r['target_url']) ?></td>
                        <td>
                            <?php if ($r['critical_count'] > 0): ?>
                                <span class="badge badge-critical"><?= $r['critical_count'] ?> critical</span>
                            <?php endif; ?>
                            <?= $r['finding_count'] ?> total
                        </td>
                        <td><?= ucfirst($r['report_type']) ?></td>
                        <td style="font-size: 0.82rem; color: var(--text-muted);"><?= date('M j, Y g:ia', strtotime($r['generated_at'])) ?></td>
                        <td>
                            <a href="/report_view.php?id=<?= $r['id'] ?>" class="btn btn-secondary btn-sm">View</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
