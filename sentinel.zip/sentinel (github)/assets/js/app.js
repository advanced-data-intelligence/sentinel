// app.js
// Sentinel - Main Application JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initClock();
    checkOllamaStatus();
    setInterval(checkOllamaStatus, 30000);
});

// Clock
function initClock() {
    const clock = document.getElementById('clock');
    if (!clock) return;

    function update() {
        const now = new Date();
        clock.textContent = now.toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }
    update();
    setInterval(update, 1000);
}

// Ollama Status Check
function checkOllamaStatus() {
    const el = document.getElementById('ollamaStatus');
    if (!el) return;

    fetch('/api/status.php')
        .then(r => r.json())
        .then(data => {
            const dot = el.querySelector('.status-dot');
            const text = el.querySelector('.status-text');

            if (data.ollama_online) {
                dot.className = 'status-dot online';
                text.textContent = data.model_available
                    ? 'Ollama: ' + data.configured_model
                    : 'Model not found';
            } else {
                dot.className = 'status-dot offline';
                text.textContent = 'Ollama: Offline';
            }
        })
        .catch(() => {
            const dot = el.querySelector('.status-dot');
            const text = el.querySelector('.status-text');
            dot.className = 'status-dot offline';
            text.textContent = 'Ollama: Error';
        });
}

// Toast Notifications
function showToast(message, type = 'info') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'toast toast-' + type;
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// Poll scan status
function pollScanStatus(scanId, callback) {
    const poll = setInterval(() => {
        fetch('/api/scan_status.php?id=' + scanId)
            .then(r => r.json())
            .then(data => {
                callback(data);
                if (data.status === 'complete' || data.status === 'failed' || data.status === 'cancelled') {
                    clearInterval(poll);
                }
            })
            .catch(err => {
                console.error('Poll error:', err);
            });
    }, 3000);

    return poll;
}

// Poll scan logs
function pollScanLogs(scanId, container, lastId = 0) {
    const poll = setInterval(() => {
        fetch('/api/scan_logs.php?scan_id=' + scanId + '&after_id=' + lastId)
            .then(r => r.json())
            .then(data => {
                if (data.logs && data.logs.length > 0) {
                    data.logs.forEach(log => {
                        const entry = document.createElement('div');
                        entry.className = 'log-entry';
                        entry.innerHTML = `
                            <span class="log-time">${log.time}</span>
                            <span class="log-level ${log.level}">${log.level}</span>
                            <span class="log-message">${escapeHtml(log.message)}</span>
                        `;
                        container.appendChild(entry);
                        lastId = log.id;
                    });
                    container.scrollTop = container.scrollHeight;
                }

                if (data.scan_status === 'complete' || data.scan_status === 'failed') {
                    clearInterval(poll);
                }
            })
            .catch(() => {});
    }, 2000);

    return poll;
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}
