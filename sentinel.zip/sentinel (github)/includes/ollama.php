<?php
// includes/ollama.php
// Ollama API Communication Helper

require_once __DIR__ . '/db.php';

class OllamaClient {
    private string $baseUrl;
    private string $model;

    public function __construct() {
        $this->baseUrl = rtrim(getSetting('ollama_url', OLLAMA_URL_DEFAULT), '/');
        $this->model = getSetting('ollama_model', OLLAMA_MODEL_DEFAULT);
    }

    /**
     * Send a prompt to Ollama and get a response
     */
    public function generate(string $prompt, string $systemPrompt = '', float $temperature = 0.3): ?string {
        $payload = [
            'model' => $this->model,
            'prompt' => $prompt,
            'stream' => false,
            'options' => [
                'temperature' => $temperature,
                'num_ctx' => 32768,
            ],
        ];

        if ($systemPrompt) {
            $payload['system'] = $systemPrompt;
        }

        $response = $this->request('/api/generate', $payload);
        return $response['response'] ?? null;
    }

    /**
     * Chat-style interaction with Ollama
     */
    public function chat(array $messages, string $systemPrompt = '', float $temperature = 0.3): ?string {
        $allMessages = [];

        if ($systemPrompt) {
            $allMessages[] = ['role' => 'system', 'content' => $systemPrompt];
        }

        foreach ($messages as $msg) {
            $allMessages[] = $msg;
        }

        $payload = [
            'model' => $this->model,
            'messages' => $allMessages,
            'stream' => false,
            'options' => [
                'temperature' => $temperature,
                'num_ctx' => 32768,
            ],
        ];

        $response = $this->request('/api/chat', $payload);
        return $response['message']['content'] ?? null;
    }

    /**
     * Analyze security tool output with the LLM
     */
    public function analyzeToolOutput(string $toolName, string $toolOutput, string $targetUrl, string $sourceCode = ''): ?string {
        $systemPrompt = <<<PROMPT
You are Sentinel, an expert penetration tester and security analyst. You analyze the output of security tools and source code to identify real, exploitable vulnerabilities.

Your analysis must be:
- Precise: Only report vulnerabilities you are confident exist
- Actionable: Include specific URLs, parameters, or code locations
- Rated: Assign severity (critical, high, medium, low, info)
- Categorized: Map to OWASP Top 10 categories
- Reproducible: Include proof-of-concept steps when possible

Respond in valid JSON format with this structure:
{
    "findings": [
        {
            "severity": "critical|high|medium|low|info",
            "category": "OWASP category name",
            "title": "Short descriptive title",
            "description": "Detailed explanation of the vulnerability",
            "affected_url": "The specific URL or endpoint affected",
            "affected_code": "Relevant code snippet if applicable",
            "proof_of_concept": "Steps or commands to reproduce",
            "remediation": "How to fix this vulnerability",
            "confidence": 0.0-1.0
        }
    ],
    "summary": "Brief overall assessment"
}

If no vulnerabilities are found, return: {"findings": [], "summary": "No vulnerabilities detected by this tool."}
PROMPT;

        $userPrompt = "## Target: {$targetUrl}\n\n";
        $userPrompt .= "## Tool: {$toolName}\n\n";
        $userPrompt .= "## Tool Output:\n```\n{$toolOutput}\n```\n\n";

        if ($sourceCode) {
            $userPrompt .= "## Relevant Source Code:\n```\n{$sourceCode}\n```\n\n";
        }

        $userPrompt .= "Analyze the above output and identify any real, exploitable vulnerabilities. Respond with valid JSON only.";

        return $this->generate($userPrompt, $systemPrompt, 0.2);
    }

    /**
     * Analyze source code for vulnerabilities
     */
    public function analyzeSourceCode(string $sourceCode, string $targetUrl, string $filePath = ''): ?string {
        $systemPrompt = <<<PROMPT
You are Sentinel, an expert code auditor specializing in application security. You perform white-box analysis of source code to identify vulnerabilities.

Focus on:
- SQL Injection (string concatenation in queries, missing parameterization)
- Cross-Site Scripting (XSS) (unescaped output, missing sanitization)
- Server-Side Request Forgery (SSRF) (user-controlled URLs in server requests)
- Broken Authentication (weak password handling, session issues, JWT flaws)
- Broken Authorization (IDOR, missing access controls, privilege escalation)
- Command Injection (user input in system/exec calls)
- Path Traversal (user input in file operations)
- Insecure Deserialization
- Hardcoded credentials or secrets

Respond in valid JSON format:
{
    "findings": [
        {
            "severity": "critical|high|medium|low|info",
            "category": "Vulnerability category",
            "title": "Short descriptive title",
            "description": "Detailed explanation",
            "affected_code": "The vulnerable code snippet with line reference",
            "file_path": "Path to the affected file",
            "proof_of_concept": "How to exploit this",
            "remediation": "How to fix it",
            "confidence": 0.0-1.0
        }
    ],
    "summary": "Brief assessment"
}
PROMPT;

        $userPrompt = "## Target Application: {$targetUrl}\n";
        if ($filePath) {
            $userPrompt .= "## File: {$filePath}\n";
        }
        $userPrompt .= "\n## Source Code:\n```\n{$sourceCode}\n```\n\n";
        $userPrompt .= "Analyze this code for security vulnerabilities. Respond with valid JSON only.";

        return $this->generate($userPrompt, $systemPrompt, 0.2);
    }

    /**
     * Generate the final pentest report
     */
    public function generateReport(array $allFindings, string $targetUrl, array $scanMeta): ?string {
        $systemPrompt = <<<PROMPT
You are Sentinel, a professional penetration testing report writer. You compile findings from multiple security tools and code analysis into a comprehensive, professional penetration test report.

The report should be in Markdown format and include:
1. Executive Summary
2. Scope and Methodology
3. Risk Summary (counts by severity)
4. Detailed Findings (ordered by severity)
5. Remediation Priority List
6. Appendix with raw tool data references

For each finding, include:
- Severity rating with visual indicator
- OWASP category mapping
- Full description
- Proof of concept
- Remediation steps
- References

Write the report in a professional tone suitable for delivery to a development team or security stakeholder.
PROMPT;

        $findingsJson = json_encode($allFindings, JSON_PRETTY_PRINT);
        $metaJson = json_encode($scanMeta, JSON_PRETTY_PRINT);

        $userPrompt = "## Target: {$targetUrl}\n\n";
        $userPrompt .= "## Scan Metadata:\n```json\n{$metaJson}\n```\n\n";
        $userPrompt .= "## All Findings:\n```json\n{$findingsJson}\n```\n\n";
        $userPrompt .= "Generate a comprehensive penetration test report in Markdown format.";

        return $this->generate($userPrompt, $systemPrompt, 0.3);
    }

    /**
     * Check if Ollama is reachable and model is available
     */
    public function healthCheck(): array {
        try {
            $response = $this->request('/api/tags', [], 'GET');
            $models = $response['models'] ?? [];
            $modelNames = array_column($models, 'name');
            $modelAvailable = in_array($this->model, $modelNames);

            // Also check partial matches (e.g., "nemotron-3-nano:30b" matches "nemotron-3-nano:30b")
            if (!$modelAvailable) {
                foreach ($modelNames as $name) {
                    if (strpos($name, explode(':', $this->model)[0]) !== false) {
                        $modelAvailable = true;
                        break;
                    }
                }
            }

            return [
                'online' => true,
                'model_available' => $modelAvailable,
                'configured_model' => $this->model,
                'available_models' => $modelNames,
            ];
        } catch (\Exception $e) {
            return [
                'online' => false,
                'model_available' => false,
                'configured_model' => $this->model,
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Make HTTP request to Ollama
     */
    private function request(string $endpoint, array $data = [], string $method = 'POST'): array {
        $url = $this->baseUrl . $endpoint;

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 600, // 10 min timeout for LLM responses
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new \RuntimeException("Ollama request failed: {$error}");
        }

        if ($httpCode >= 400) {
            throw new \RuntimeException("Ollama returned HTTP {$httpCode}: {$response}");
        }

        return json_decode($response, true) ?: [];
    }
}
