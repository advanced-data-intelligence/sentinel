<?php
// includes/tools.php
// Security Tool Wrapper - Executes and manages security scanning tools

require_once __DIR__ . '/db.php';

class ToolRunner {
    private int $scanId;
    private string $targetUrl;
    private string $targetHost;
    private int $targetPort;

    public function __construct(int $scanId, string $targetUrl) {
        $this->scanId = $scanId;
        $this->targetUrl = $targetUrl;

        $parsed = parse_url($targetUrl);
        $this->targetHost = $parsed['host'] ?? '';
        $this->targetPort = $parsed['port'] ?? ($parsed['scheme'] === 'https' ? 443 : 80);
    }

    /**
     * Run Nmap scan
     */
    public function runNmap(): array {
        $nmapPath = getSetting('nmap_path', '/usr/bin/nmap');
        $this->logStart('nmap');

        // Service detection + common scripts
        $cmd = sprintf(
            'sudo %s -sV -sC --script=http-enum,http-headers,http-methods,http-title -p %d %s -oN - 2>&1',
            escapeshellarg($nmapPath),
            $this->targetPort,
            escapeshellarg($this->targetHost)
        );

        return $this->execute('nmap', 'recon', $cmd);
    }

    /**
     * Run WhatWeb scan
     */
    public function runWhatWeb(): array {
        $whatwebPath = getSetting('whatweb_path', '/usr/bin/whatweb');
        $this->logStart('whatweb');

        $cmd = sprintf(
            'sudo %s -v -a 3 %s 2>&1',
            escapeshellarg($whatwebPath),
            escapeshellarg($this->targetUrl)
        );

        return $this->execute('whatweb', 'recon', $cmd);
    }

    /**
     * Run Nikto scan
     */
    public function runNikto(): array {
        $niktoPath = getSetting('nikto_path', '/usr/bin/nikto');
        $this->logStart('nikto');

        $cmd = sprintf(
            'sudo %s -h %s -C all -timeout 10 -maxtime 300 2>&1',
            escapeshellarg($niktoPath),
            escapeshellarg($this->targetUrl)
        );

        return $this->execute('nikto', 'vuln_scan', $cmd);
    }

    /**
     * Run Dirb scan
     */
    public function runDirb(): array {
        $dirbPath = getSetting('dirb_path', '/usr/bin/dirb');
        $this->logStart('dirb');

        $cmd = sprintf(
            'sudo %s %s /usr/share/dirb/wordlists/common.txt -S -r 2>&1',
            escapeshellarg($dirbPath),
            escapeshellarg($this->targetUrl)
        );

        return $this->execute('dirb', 'recon', $cmd);
    }

    /**
     * Run SQLMap scan
     */
    public function runSqlmap(string $targetParam = ''): array {
        $sqlmapPath = getSetting('sqlmap_path', '/usr/bin/sqlmap');
        $this->logStart('sqlmap');

        $target = $targetParam ?: $this->targetUrl;

        $cmd = sprintf(
            'sudo %s -u %s --batch --level=2 --risk=1 --forms --crawl=2 --threads=4 --timeout=30 --retries=2 --output-dir=/tmp/sqlmap_%d 2>&1',
            escapeshellarg($sqlmapPath),
            escapeshellarg($target),
            $this->scanId
        );

        return $this->execute('sqlmap', 'exploitation', $cmd);
    }

    /**
     * Run Nuclei scan
     */
    public function runNuclei(): array {
        $nucleiPath = getSetting('nuclei_path', '/usr/local/bin/nuclei');
        $this->logStart('nuclei');

        $cmd = sprintf(
            'sudo %s -u %s -severity critical,high,medium -timeout 10 -retries 2 -c 25 2>&1',
            escapeshellarg($nucleiPath),
            escapeshellarg($this->targetUrl)
        );

        return $this->execute('nuclei', 'vuln_scan', $cmd);
    }

    /**
     * Run Subfinder for subdomain enumeration
     */
    public function runSubfinder(): array {
        $subfinderPath = getSetting('subfinder_path', '/usr/local/bin/subfinder');
        $this->logStart('subfinder');

        $cmd = sprintf(
            'sudo %s -d %s -silent 2>&1',
            escapeshellarg($subfinderPath),
            escapeshellarg($this->targetHost)
        );

        return $this->execute('subfinder', 'recon', $cmd);
    }

    /**
     * Run HTTP header analysis with curl
     */
    public function runHeaderAnalysis(): array {
        $this->logStart('headers');

        $cmd = sprintf(
            'curl -sI -L -4 --connect-timeout 5 --max-time 20 -A %s %s 2>&1',
            escapeshellarg('Sentinel-Scanner'),
            escapeshellarg($this->targetUrl)
        );

        return $this->execute('headers', 'recon', $cmd);
    }

    /**
     * Read and collect source code files from a directory
     */
    public function collectSourceCode(string $sourcePath, array $extensions = ['php', 'js', 'py', 'rb', 'java', 'go', 'ts', 'jsx', 'tsx', 'html', 'sql', 'env', 'yml', 'yaml', 'json', 'xml', 'conf']): array {
        $files = [];

        if (!is_dir($sourcePath)) {
            addScanLog($this->scanId, "Source path not found: {$sourcePath}", 'error');
            return $files;
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($sourcePath, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        // Skip common non-essential directories
        $skipDirs = ['node_modules', 'vendor', '.git', '__pycache__', '.next', 'dist', 'build', '.cache'];

        foreach ($iterator as $file) {
            if ($file->isDir()) continue;

            $path = $file->getPathname();
            $relativePath = str_replace($sourcePath . '/', '', $path);

            // Skip unwanted directories
            $skip = false;
            foreach ($skipDirs as $skipDir) {
                if (strpos($relativePath, $skipDir . '/') !== false) {
                    $skip = true;
                    break;
                }
            }
            if ($skip) continue;

            $ext = strtolower($file->getExtension());
            if (in_array($ext, $extensions) && $file->getSize() < 500000) { // Skip files > 500KB
                $content = @file_get_contents($path);
                if ($content !== false) {
                    $files[] = [
                        'path' => $relativePath,
                        'extension' => $ext,
                        'size' => $file->getSize(),
                        'content' => $content,
                    ];
                }
            }
        }

        addScanLog($this->scanId, "Collected " . count($files) . " source files from {$sourcePath}", 'info');
        return $files;
    }

    /**
     * Execute a tool command and store results
     */
    private function execute(string $toolName, string $phase, string $cmd): array {
        $db = getDB();

        // Create scan_result record
        $stmt = $db->prepare("INSERT INTO scan_results (scan_id, tool_name, phase, status, started_at) VALUES (?, ?, ?, 'running', NOW())");
        $stmt->execute([$this->scanId, $toolName, $phase]);
        $resultId = $db->lastInsertId();

        addScanLog($this->scanId, "Running {$toolName}: {$cmd}", 'debug');

        // Execute with timeout
        $descriptors = [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];

        $process = proc_open($cmd, $descriptors, $pipes);

        if (!is_resource($process)) {
            $this->logEnd($toolName, $resultId, 'failed', '');
            return ['success' => false, 'output' => '', 'tool' => $toolName];
        }

        fclose($pipes[0]);
        $output = stream_get_contents($pipes[1]);
        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);

        $exitCode = proc_close($process);
        $fullOutput = $output . ($stderr ? "\n--- STDERR ---\n" . $stderr : '');

        // Update scan_result
        $status = ($exitCode === 0 || !empty($output)) ? 'complete' : 'failed';
        $this->logEnd($toolName, $resultId, $status, $fullOutput);

        addScanLog($this->scanId, "{$toolName} completed with exit code {$exitCode} (" . strlen($output) . " bytes output)", 'info');

        return [
            'success' => $status === 'complete',
            'output' => $fullOutput,
            'tool' => $toolName,
            'result_id' => $resultId,
        ];
    }

    private function logStart(string $toolName): void {
        addScanLog($this->scanId, "Starting {$toolName} scan against {$this->targetUrl}", 'info');
    }

    private function logEnd(string $toolName, int $resultId, string $status, string $output): void {
        $db = getDB();
        $stmt = $db->prepare("UPDATE scan_results SET status = ?, raw_output = ?, completed_at = NOW() WHERE id = ?");
        $stmt->execute([$status, $output, $resultId]);
    }
}
