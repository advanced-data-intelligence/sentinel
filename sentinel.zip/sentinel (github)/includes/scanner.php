<?php
// includes/scanner.php
// Scan Orchestrator - Manages the full pentest workflow

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/tools.php';
require_once __DIR__ . '/ollama.php';

class Scanner {
    private int $scanId;
    private string $targetUrl;
    private ?string $sourcePath;
    private string $scanType;
    private ToolRunner $tools;
    private OllamaClient $ollama;

    public function __construct(int $scanId) {
        $this->scanId = $scanId;

        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM scans WHERE id = ?");
        $stmt->execute([$scanId]);
        $scan = $stmt->fetch();

        if (!$scan) {
            throw new \RuntimeException("Scan #{$scanId} not found");
        }

        $this->targetUrl = $scan['target_url'];
        $this->sourcePath = $scan['source_path'];
        $this->scanType = $scan['scan_type'];
        $this->tools = new ToolRunner($scanId, $this->targetUrl);
        $this->ollama = new OllamaClient();
    }

    /**
     * Run the full pentest workflow
     */
    public function run(): void {
        $this->updateStatus('running', 0, 'Initializing');
        addScanLog($this->scanId, "=== Sentinel Scan Started ===", 'info');
        addScanLog($this->scanId, "Target: {$this->targetUrl}", 'info');
        addScanLog($this->scanId, "Scan Type: {$this->scanType}", 'info');

        try {
            // Phase 1: Reconnaissance
            $this->updateStatus('running', 10, 'Phase 1: Reconnaissance');
            $reconResults = $this->phaseRecon();

            if ($this->scanType === 'recon') {
                $this->updateStatus('analyzing', 60, 'AI Analysis of recon data');
                $aiFindings = $this->phaseAIAnalysis($reconResults, []);
                $this->updateStatus('analyzing', 85, 'Generating report');
                $this->generateReport($reconResults, $aiFindings);
                $this->updateStatus('complete', 100, 'Complete');
                return;
            }

            // Phase 2: Vulnerability Analysis (tools + code)
            $this->updateStatus('running', 30, 'Phase 2: Vulnerability Analysis');
            $vulnResults = $this->phaseVulnAnalysis();

            if ($this->scanType === 'quick') {
                $this->updateStatus('analyzing', 60, 'AI Analysis of tool outputs');
                $aiFindings = $this->phaseAIAnalysis($reconResults, $vulnResults);
                $this->updateStatus('analyzing', 85, 'Generating report');
                $this->generateReport(array_merge($reconResults, $vulnResults), $aiFindings);
                $this->updateStatus('complete', 100, 'Complete');
                return;
            }

            // Phase 3: AI-Powered Deep Analysis
            $this->updateStatus('analyzing', 55, 'Phase 3: AI Deep Analysis');
            $aiFindings = $this->phaseAIAnalysis($reconResults, $vulnResults);

            // Phase 4: Source Code Analysis
            if ($this->sourcePath && is_dir($this->sourcePath)) {
                $this->updateStatus('analyzing', 70, 'Phase 4: Source Code Analysis');
                $codeFindings = $this->phaseCodeAnalysis();
                $aiFindings = array_merge($aiFindings, $codeFindings);
            }

            // Phase 5: Report Generation
            $this->updateStatus('analyzing', 85, 'Phase 5: Generating Report');
            $this->generateReport(array_merge($reconResults, $vulnResults), $aiFindings);

            $this->updateStatus('complete', 100, 'Complete');
            addScanLog($this->scanId, "=== Sentinel Scan Complete ===", 'info');

        } catch (\Exception $e) {
            addScanLog($this->scanId, "Scan failed: " . $e->getMessage(), 'error');
            $this->updateStatus('failed', 0, 'Failed: ' . $e->getMessage());
        }
    }

    /**
     * Phase 1: Reconnaissance
     */
    private function phaseRecon(): array {
        addScanLog($this->scanId, "--- Phase 1: Reconnaissance ---", 'info');
        $results = [];

        // Run recon tools
        $this->updateStatus('running', 10, 'Recon: Port scanning (Nmap)');
        $results[] = $this->tools->runNmap();

        $this->updateStatus('running', 14, 'Recon: Technology fingerprinting (WhatWeb)');
        $results[] = $this->tools->runWhatWeb();

        $this->updateStatus('running', 18, 'Recon: HTTP headers analysis');
        $results[] = $this->tools->runHeaderAnalysis();

        $this->updateStatus('running', 22, 'Recon: Directory enumeration (Dirb)');
        $results[] = $this->tools->runDirb();

        $this->updateStatus('running', 26, 'Recon: Subdomain enumeration (Subfinder)');
        $results[] = $this->tools->runSubfinder();

        return $results;
    }

    /**
     * Phase 2: Vulnerability Scanning
     */
    private function phaseVulnAnalysis(): array {
        addScanLog($this->scanId, "--- Phase 2: Vulnerability Analysis ---", 'info');
        $results = [];

        $this->updateStatus('running', 35, 'Vuln Scan: Web server scanner (Nikto)');
        $results[] = $this->tools->runNikto();

        $this->updateStatus('running', 42, 'Vuln Scan: Template scanner (Nuclei)');
        $results[] = $this->tools->runNuclei();

        $this->updateStatus('running', 48, 'Vuln Scan: SQL injection testing (SQLMap)');
        $results[] = $this->tools->runSqlmap();

        return $results;
    }

    /**
     * Phase 3: AI-Powered Deep Analysis of tool outputs
     */
    private function phaseAIAnalysis(array $reconResults, array $vulnResults): array {
        addScanLog($this->scanId, "--- Phase 3: AI Deep Analysis ---", 'info');
        $allFindings = [];

        $allResults = array_merge($reconResults, $vulnResults);
        $totalResults = count($allResults);
        $processed = 0;

        foreach ($allResults as $result) {
            if (!$result['success'] || empty($result['output'])) {
                $processed++;
                continue;
            }

            $pct = 55 + intval(($processed / max($totalResults, 1)) * 15);
            $this->updateStatus('analyzing', $pct, "AI Analysis: Analyzing {$result['tool']} output");

            addScanLog($this->scanId, "AI analyzing output from {$result['tool']}...", 'info');

            try {
                $response = $this->ollama->analyzeToolOutput(
                    $result['tool'],
                    $result['output'],
                    $this->targetUrl
                );

                if ($response) {
                    $findings = $this->parseAIResponse($response, $result['tool']);
                    $allFindings = array_merge($allFindings, $findings);
                    addScanLog($this->scanId, "AI found " . count($findings) . " findings from {$result['tool']}", 'info');
                }
            } catch (\Exception $e) {
                addScanLog($this->scanId, "AI analysis of {$result['tool']} failed: " . $e->getMessage(), 'warning');
            }

            $processed++;
        }

        return $allFindings;
    }

    /**
     * Phase 4: Source Code Analysis
     */
    private function phaseCodeAnalysis(): array {
        addScanLog($this->scanId, "--- Phase 4: Source Code Analysis ---", 'info');
        $allFindings = [];

        $sourceFiles = $this->tools->collectSourceCode($this->sourcePath);
        $totalFiles = count($sourceFiles);

        if ($totalFiles === 0) {
            addScanLog($this->scanId, "No source files found to analyze", 'warning');
            return [];
        }

        // Batch files to avoid overwhelming the LLM
        $batchSize = 5;
        $batches = array_chunk($sourceFiles, $batchSize);
        $batchNum = 0;

        foreach ($batches as $batch) {
            $batchNum++;
            $pct = 70 + intval(($batchNum / max(count($batches), 1)) * 15);
            $this->updateStatus('analyzing', $pct, "Code Analysis: Batch {$batchNum}/" . count($batches));

            // Combine batch into one prompt
            $combinedCode = '';
            foreach ($batch as $file) {
                $combinedCode .= "\n\n=== FILE: {$file['path']} ===\n";
                $combinedCode .= $file['content'];
            }

            // Truncate if too large (keep within reasonable token limits)
            if (strlen($combinedCode) > 100000) {
                $combinedCode = substr($combinedCode, 0, 100000) . "\n\n[TRUNCATED]";
            }

            try {
                $response = $this->ollama->analyzeSourceCode(
                    $combinedCode,
                    $this->targetUrl,
                    "Batch {$batchNum}"
                );

                if ($response) {
                    $findings = $this->parseAIResponse($response, 'code_analysis');
                    $allFindings = array_merge($allFindings, $findings);
                }
            } catch (\Exception $e) {
                addScanLog($this->scanId, "Code analysis batch {$batchNum} failed: " . $e->getMessage(), 'warning');
            }
        }

        addScanLog($this->scanId, "Code analysis found " . count($allFindings) . " findings across {$totalFiles} files", 'info');
        return $allFindings;
    }

    /**
     * Parse AI JSON response and store findings
     */
    private function parseAIResponse(string $response, string $sourceTool): array {
        $findings = [];

        // Try to extract JSON from the response
        $jsonStr = $response;

        // Sometimes the LLM wraps JSON in markdown code blocks
        if (preg_match('/```(?:json)?\s*(\{.*?\})\s*```/s', $response, $matches)) {
            $jsonStr = $matches[1];
        }

        $data = json_decode($jsonStr, true);
        if (!$data || !isset($data['findings'])) {
            // Try to find JSON object in the response
            if (preg_match('/\{[^{}]*"findings"\s*:\s*\[.*?\]\s*[^{}]*\}/s', $response, $matches)) {
                $data = json_decode($matches[0], true);
            }
        }

        if (!$data || !isset($data['findings'])) {
            addScanLog($this->scanId, "Failed to parse AI response from {$sourceTool}", 'warning');
            return [];
        }

        $db = getDB();
        $stmt = $db->prepare(
            "INSERT INTO findings (scan_id, severity, category, title, description, affected_url, affected_code, proof_of_concept, remediation, ai_confidence, source_tool) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        foreach ($data['findings'] as $f) {
            $severity = $f['severity'] ?? 'info';
            if (!in_array($severity, ['critical', 'high', 'medium', 'low', 'info'])) {
                $severity = 'info';
            }

            $stmt->execute([
                $this->scanId,
                $severity,
                $f['category'] ?? 'Unknown',
                $f['title'] ?? 'Untitled Finding',
                $f['description'] ?? '',
                $f['affected_url'] ?? $this->targetUrl,
                $f['affected_code'] ?? ($f['file_path'] ?? ''),
                $f['proof_of_concept'] ?? '',
                $f['remediation'] ?? '',
                $f['confidence'] ?? null,
                $sourceTool,
            ]);

            $findings[] = $f;
        }

        return $findings;
    }

    /**
     * Generate the final report
     */
    private function generateReport(array $toolResults, array $aiFindings): void {
        addScanLog($this->scanId, "Generating final report...", 'info');

        // Get all findings from DB
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM findings WHERE scan_id = ? ORDER BY FIELD(severity, 'critical', 'high', 'medium', 'low', 'info'), created_at");
        $stmt->execute([$this->scanId]);
        $allFindings = $stmt->fetchAll();

        $scanMeta = [
            'scan_id' => $this->scanId,
            'target_url' => $this->targetUrl,
            'scan_type' => $this->scanType,
            'source_analyzed' => !empty($this->sourcePath),
            'tools_used' => array_unique(array_column($allFindings, 'source_tool')),
            'total_findings' => count($allFindings),
            'critical' => count(array_filter($allFindings, fn($f) => $f['severity'] === 'critical')),
            'high' => count(array_filter($allFindings, fn($f) => $f['severity'] === 'high')),
            'medium' => count(array_filter($allFindings, fn($f) => $f['severity'] === 'medium')),
            'low' => count(array_filter($allFindings, fn($f) => $f['severity'] === 'low')),
            'info' => count(array_filter($allFindings, fn($f) => $f['severity'] === 'info')),
        ];

        try {
            $reportContent = $this->ollama->generateReport($allFindings, $this->targetUrl, $scanMeta);
        } catch (\Exception $e) {
            addScanLog($this->scanId, "AI report generation failed, generating basic report: " . $e->getMessage(), 'warning');
            $reportContent = $this->generateBasicReport($allFindings, $scanMeta);
        }

        // Save report
        $reportPath = REPORTS_DIR . "/sentinel_report_{$this->scanId}_" . date('Ymd_His') . ".md";
        file_put_contents($reportPath, $reportContent);

        $stmt = $db->prepare("INSERT INTO reports (scan_id, report_type, content, file_path) VALUES (?, 'full', ?, ?)");
        $stmt->execute([$this->scanId, $reportContent, $reportPath]);

        addScanLog($this->scanId, "Report saved: {$reportPath}", 'info');
    }

    /**
     * Fallback basic report if AI report generation fails
     */
    private function generateBasicReport(array $findings, array $meta): string {
        $report = "# Sentinel Security Assessment Report\n\n";
        $report .= "**Target:** {$meta['target_url']}\n";
        $report .= "**Date:** " . date('Y-m-d H:i:s') . "\n";
        $report .= "**Scan Type:** {$meta['scan_type']}\n\n";

        $report .= "## Risk Summary\n\n";
        $report .= "| Severity | Count |\n|----------|-------|\n";
        $report .= "| Critical | {$meta['critical']} |\n";
        $report .= "| High | {$meta['high']} |\n";
        $report .= "| Medium | {$meta['medium']} |\n";
        $report .= "| Low | {$meta['low']} |\n";
        $report .= "| Info | {$meta['info']} |\n\n";

        $report .= "## Findings\n\n";
        foreach ($findings as $f) {
            $report .= "### [{$f['severity']}] {$f['title']}\n\n";
            $report .= "**Category:** {$f['category']}\n\n";
            $report .= "{$f['description']}\n\n";
            if ($f['proof_of_concept']) {
                $report .= "**Proof of Concept:**\n```\n{$f['proof_of_concept']}\n```\n\n";
            }
            if ($f['remediation']) {
                $report .= "**Remediation:** {$f['remediation']}\n\n";
            }
            $report .= "---\n\n";
        }

        return $report;
    }

    /**
     * Update scan status in DB
     */
    private function updateStatus(string $status, int $progress, string $phase): void {
        $db = getDB();
        $updates = ['status = ?', 'progress = ?', 'current_phase = ?'];
        $params = [$status, $progress, $phase];

        if ($status === 'running' && $progress <= 10) {
            $updates[] = 'started_at = NOW()';
        }
        if ($status === 'complete' || $status === 'failed') {
            $updates[] = 'completed_at = NOW()';
        }

        $params[] = $this->scanId;
        $sql = "UPDATE scans SET " . implode(', ', $updates) . " WHERE id = ?";
        $db->prepare($sql)->execute($params);
    }
}