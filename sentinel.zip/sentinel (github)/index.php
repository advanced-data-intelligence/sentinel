<?php
// index.php
// Main Dashboard

require_once __DIR__ . '/includes/db.php';

$pageTitle = 'Dashboard';
$db = getDB();

// Stats
$totalScans = $db->query("SELECT COUNT(*) FROM scans")->fetchColumn();
$activeScans = $db->query("SELECT COUNT(*) FROM scans WHERE status IN ('running', 'analyzing')")->fetchColumn();
$totalFindings = $db->query("SELECT COUNT(*) FROM findings")->fetchColumn();
$criticalFindings = $db->query("SELECT COUNT(*) FROM findings WHERE severity = 'critical'")->fetchColumn();

// Recent scans
$recentScans = $db->query("SELECT * FROM scans ORDER BY created_at DESC LIMIT 10")->fetchAll();

// Severity breakdown
$severityCounts = $db->query("SELECT severity, COUNT(*) as cnt FROM findings GROUP BY severity")->fetchAll(PDO::FETCH_KEY_PAIR);

require_once __DIR__ . '/templates/header.php';
?>

<!-- Stats Grid -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon accent">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M10 3L4 6.5v5C4 15.4 6.7 19 10 20c3.3-1 6-4.6 6-8.5v-5L10 3z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>
        </div>
        <div>
            <div class="stat-value"><?= $totalScans ?></div>
            <div class="stat-label">Total Scans</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background: rgba(14, 165, 233, 0.1); color: var(--status-running);">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M10 6v4l2.5 2.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
        </div>
        <div>
            <div class="stat-value"><?= $activeScans ?></div>
            <div class="stat-label">Active Scans</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon warning">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M10 3L2 17h16L10 3z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><path d="M10 8v4M10 14v.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
        </div>
        <div>
            <div class="stat-value"><?= $totalFindings ?></div>
            <div class="stat-label">Total Findings</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon critical">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M7.5 7.5l5 5M12.5 7.5l-5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
        </div>
        <div>
            <div class="stat-value"><?= $criticalFindings ?></div>
            <div class="stat-label">Critical Findings</div>
        </div>
    </div>
</div>

<!-- Recent Scans -->
<div class="card section">
    <div class="card-header">
        <div>
            <div class="card-title">Recent Scans</div>
            <div class="card-subtitle">Latest security assessments</div>
        </div>
        <a href="/new_scan.php" class="btn btn-primary btn-sm">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 2v10M2 7h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
            New Scan
        </a>
    </div>

    <?php if (empty($recentScans)): ?>
        <div class="empty-state">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none"><path d="M24 8L12 14v10c0 8.4 5.1 16.2 12 18.2 6.9-2 12-9.8 12-18.2V14L24 8z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>
            <h3>No scans yet</h3>
            <p>Launch your first security assessment to get started.</p>
            <a href="/new_scan.php" class="btn btn-primary">Start First Scan</a>
        </div>
    <?php else: ?>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Scan</th>
                        <th>Target</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Progress</th>
                        <th>Created</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentScans as $scan): ?>
                    <tr>
                        <td style="color: var(--text-primary); font-weight: 500;"><?= htmlspecialchars($scan['scan_name']) ?></td>
                        <td>
                            <span style="font-family: var(--font-mono); font-size: 0.82rem;"><?= htmlspecialchars($scan['target_url']) ?></span>
                        </td>
                        <td><?= ucfirst($scan['scan_type']) ?></td>
                        <td><span class="badge badge-<?= $scan['status'] ?>"><?= ucfirst($scan['status']) ?></span></td>
                        <td>
                            <div class="scan-progress">
                                <div class="progress-bar">
                                    <div class="progress-fill <?= $scan['status'] === 'complete' ? 'complete' : '' ?>" style="width: <?= $scan['progress'] ?>%"></div>
                                </div>
                                <span class="progress-text"><?= $scan['progress'] ?>%</span>
                            </div>
                        </td>
                        <td style="font-size: 0.82rem; color: var(--text-muted);"><?= date('M j, g:ia', strtotime($scan['created_at'])) ?></td>
                        <td><a href="/scan_detail.php?id=<?= $scan['id'] ?>" class="btn btn-secondary btn-sm">View</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
